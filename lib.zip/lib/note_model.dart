import 'package:flutter/material.dart';

class Note {
  final String title;
  final String content;
  final DateTime createTime;
  final DateTime updateTime;
  final Color textColor;
  final List<String> imagePaths;
  final bool isFavorite;
  final String category; // 🚀 核心升级：改为 String，支持无限自定义分类！
  final List<String> tags;
  final bool hasHistoryLink;

  Note({
    required this.title,
    required this.content,
    required this.createTime,
    required this.updateTime,
    this.textColor = Colors.black,
    this.imagePaths = const [],
    this.isFavorite = false,
    this.category = '其他', // 默认分类
    this.tags = const [],
    this.hasHistoryLink = false,
  });

  Map<String, dynamic> toJson() {
    return {
      'title': title,
      'content': content,
      'createTime': createTime.toIso8601String(),
      'updateTime': updateTime.toIso8601String(),
      'textColor': textColor.value.toString(),
      'imagePaths': imagePaths,
      'isFavorite': isFavorite,
      'category': category,
      'tags': tags,
      'hasHistoryLink': hasHistoryLink,
    };
  }

  static Note fromJson(Map<String, dynamic> json) {
    // 兼容旧版数据的安全拦截机制
    String parsedCategory = '其他';
    if (json['category'] != null) {
      String raw = json['category'].toString();
      // 如果读取到旧版本的枚举数据，自动转换为新的数学标签
      if (raw == 'NoteCategory.work') parsedCategory = '代数';
      else if (raw == 'NoteCategory.life') parsedCategory = '几何';
      else if (raw == 'NoteCategory.study') parsedCategory = '微积分';
      else if (raw == 'NoteCategory.other') parsedCategory = '其他';
      else parsedCategory = raw; 
    }

    return Note(
      title: json['title'] ?? '',
      content: json['content'] ?? '',
      createTime: DateTime.parse(json['createTime']),
      updateTime: DateTime.parse(json['updateTime'] ?? json['createTime']),
      textColor: Color(int.parse(json['textColor'] ?? Colors.black.value.toString())),
      imagePaths: List<String>.from(json['imagePaths'] ?? []),
      isFavorite: json['isFavorite'] ?? false,
      category: parsedCategory,
      tags: List<String>.from(json['tags'] ?? []),
      hasHistoryLink: json['hasHistoryLink'] ?? false,
    );
  }
}